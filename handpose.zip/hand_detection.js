// Global variables
let video;
let canvas;
let ctx;
let model;
let currentModelType = 'lite';
let lastFrameTime = 0;
let fps = 0;

// DOM elements
const modelTypeSelect = document.getElementById('modelType');
const fpsElement = document.getElementById('fps');

// Main function
async function setupCamera() {
    video = document.getElementById('video');
    canvas = document.getElementById('output');
    ctx = canvas.getContext('2d');
    
    try {
        // First check if we already have permission
        const devices = await navigator.mediaDevices.enumerateDevices();
        const hasCameraPermission = devices.some(device => device.kind === 'videoinput' && device.label !== '');
        
        if (!hasCameraPermission) {
            // Explicitly request permission if we don't have it
            await requestCameraPermission();
        }
        
        const stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
                width: { ideal: 640 },
                height: { ideal: 480 }
            }
        });
        
        video.srcObject = stream;
        
        return new Promise((resolve) => {
            video.onloadedmetadata = () => {
                video.play();
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                resolve(video);
            };
        });
    } catch (err) {
        console.error('Error accessing camera:', err);
        showCameraError();
        throw err;
    }
}

async function requestCameraPermission() {
    try {
        // Create a temporary stream just to trigger permission prompt
        const tempStream = await navigator.mediaDevices.getUserMedia({ 
            video: true,
            audio: false 
        });
        // Immediately stop the stream
        tempStream.getTracks().forEach(track => track.stop());
    } catch (err) {
        console.error('Camera permission denied:', err);
        throw err;
    }
}

function showCameraError() {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'camera-error';
    errorDiv.innerHTML = `
        <h3>Camera Access Required</h3>
        <p>This application needs camera access to work. Please allow camera permissions and refresh the page.</p>
        <button onclick="location.reload()" style="padding: 8px 16px; background: white; border: none; border-radius: 4px; cursor: pointer;">
            Refresh Page
        </button>
    `;
    document.body.appendChild(errorDiv);
}

async function loadModel() {
    console.log('Loading handpose model...');
    model = await handpose.load({
        maxContinuousChecks: 5,
        detectionConfidence: 0.8,
        maxHands: 2,
        modelType: currentModelType
    });
    console.log('Model loaded');
}

function drawHandPredictions(predictions) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Latar belakang hitam (opsional)
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    if (predictions && predictions.length > 0) {
        predictions.forEach(prediction => {
            const landmarks = prediction.landmarks;
            const handedness = prediction.handedness;
            
            // Set warna berdasarkan tangan kanan/kiri
            if (handedness === 'left') {
                ctx.fillStyle = 'red';
                ctx.strokeStyle = '#ff9999';
            } else {
                ctx.fillStyle = 'blue';
                ctx.strokeStyle = '#9999ff';
            }
            
            // Gambar landmarks
            for (let i = 0; i < landmarks.length; i++) {
                const [x, y] = landmarks[i];
                ctx.beginPath();
                ctx.arc(x, y, 5, 0, 2 * Math.PI);
                ctx.fill();
            }
            
            // Gambar koneksi jari
            const fingerIndices = [
                [0, 1, 2, 3, 4], [0, 5, 6, 7, 8], 
                [0, 9, 10, 11, 12], [0, 13, 14, 15, 16], 
                [0, 17, 18, 19, 20]
            ];
            
            fingerIndices.forEach(finger => {
                for (let i = 0; i < finger.length - 1; i++) {
                    const start = landmarks[finger[i]];
                    const end = landmarks[finger[i + 1]];
                    ctx.beginPath();
                    ctx.moveTo(start[0], start[1]);
                    ctx.lineTo(end[0], end[1]);
                    ctx.stroke();
                }
            });
        });
    }
}
async function detectHands() {
    if (!model || !video.srcObject) return;
    
    const now = performance.now();
    const predictions = await model.estimateHands(video);
    
    // Calculate FPS
    if (lastFrameTime) {
        fps = 1000 / (now - lastFrameTime);
        fpsElement.textContent = `FPS: ${fps.toFixed(1)}`;
    }
    lastFrameTime = now;
    
    drawHandPredictions(predictions);
    requestAnimationFrame(detectHands);
}

// Event listeners
modelTypeSelect.addEventListener('change', async (e) => {
    currentModelType = e.target.value;
    await loadModel();
});

// Initialize
async function init() {
    try {
        // Show loading message
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'loading-overlay';
        loadingDiv.innerHTML = '<h2>Loading application...</h2>';
        document.body.appendChild(loadingDiv);
        
        await setupCamera();
        await loadModel();
        
        // Remove loading message
        document.body.removeChild(loadingDiv);
        
        detectHands();
    } catch (err) {
        console.error('Initialization error:', err);
    }
}

// Start when page loads
window.addEventListener('DOMContentLoaded', init);
